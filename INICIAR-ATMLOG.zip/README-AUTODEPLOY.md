# ATMLog — Auto-Deploy v2 (banco à prova de restart)

## O que mudou nesta versão
- 🛡️ **O banco NÃO é mais apagado ao reiniciar.** Antes o banco (`pb_data`) ficava
  **dentro** do repositório que se auto-atualiza, então o `git reset` da atualização
  zerava tudo. Agora o `pb_data` fica **FORA** do repositório, numa pasta fixa
  (`...\deploy\pb_data`), que nenhuma atualização/clone toca.
- 💾 **Backups automáticos**: a cada 6 horas, ao subir, antes de cada atualização,
  antes de pausar e ao sair — salvos em `...\deploy\Backups\` (mantém os 12 mais recentes).
- ♻️ **Restauração**: se o banco estiver vazio, ele **pergunta** se você quer restaurar
  um backup (ou migrar dados antigos) antes de iniciar.
- ⏸️ **Pausar/Retomar** com a tecla **P** (sem precisar fechar tudo).

## Estrutura na máquina (pasta `deploy`)
```
deploy\
  INICIAR-ATMLOG.bat     <- você executa este
  auto-deploy.js         <- o "motor" (rodado pelo .bat)
  ATMLog-Sistema\        <- o código (repositório) - pode ser atualizado à vontade
  pb_data\               <- O BANCO (fica aqui, FORA do repo) *NUNCA é apagado por update*
  Backups\               <- backups automáticos e manuais
```

## Teclas (no terminal do auto-deploy)
- **R** = reiniciar os servidores
- **U** = verificar/atualizar agora (sem esperar os 30s)
- **P** = **pausar / retomar** o sistema (para PocketBase + Backend, sem fechar o vigia)
- **B** = fazer um **backup** agora
- **Q** = parar tudo e sair (faz um backup final antes)
- **H** = mostrar as teclas

## Como aplicar esta atualização na máquina do Natan (SEM perder os backups)
1. Feche o auto-deploy atual (aperte **Q**; se não fechar, feche a janela do CMD).
2. Extraia o **INICIAR-ATMLOG.zip** por cima da pasta `...\Desktop\ATMLog\deploy\`
   (isso substitui apenas o `INICIAR-ATMLOG.bat` e o `auto-deploy.js`; a pasta
   `Backups\` e o `ATMLog-Sistema\` continuam intactos).
3. Rode o **INICIAR-ATMLOG.bat** (como Administrador).
4. Na primeira vez, o banco novo (`pb_data`) estará vazio, então ele vai **perguntar**:
   - escolha a opção que mostra **`pb_backup_acme_20260629115141`** (ou o backup mais recente)
     para **restaurar os dados perdidos**.
5. Quando aparecer **"ATMLog NO AR"**, pronto — e a partir daí **nenhum restart apaga
   mais o banco**, e ele passa a fazer backups sozinho.

> Observação: os backups são cópias "a quente" dos arquivos do PocketBase (banco pequeno,
> o SQLite recupera pelo WAL). Para um backup 100% consistente, use a tecla **P** (pausa)
> e depois **B**, ou **Q** (que faz backup ao sair).
